// Deterministic Core Engine for StatementVault
declare const require: any;
const crypto = require("crypto");

export type TransactionType = "DEBIT" | "CREDIT";

export interface StatementTransaction {
  id: string;
  date: string;
  description: string;
  type: TransactionType;
  amountCents: number;
  amountFormatted: string;
  runningBalanceCents?: number;
  runningBalanceFormatted?: string;
  category?: string;
  checkNumber?: string;
}

export interface StatementMetadata {
  bankName: string;
  accountNumberMasked: string;
  statementPeriod?: string;
  statedOpeningBalanceCents: number;
  statedEndingBalanceCents: number;
  currency: string;
}

export interface StatementAuditReceipt {
  statementId: string;
  metadata: StatementMetadata;
  transactions: StatementTransaction[];
  totalCreditsCents: number;
  totalDebitsCents: number;
  calculatedEndingBalanceCents: number;
  discrepancyCents: number;
  isDeterministicPass: boolean;
  status: "EXACT_BALANCE_MATCH" | "DISCREPANCY_FLAGGED";
  auditMessage: string;
  timestamp: string;
  checksumSha256: string;
}

export class StatementVaultCore {
  public static toCents(val: number): number {
    return Math.round(Number((val * 100).toFixed(4)));
  }

  public static formatCents(cents: number): string {
    const isNeg = cents < 0;
    const abs = Math.abs(cents);
    const dollars = (abs / 100).toFixed(2);
    return isNeg ? `-$${dollars}` : `$${dollars}`;
  }

  /**
   * Deterministic Statement Text Parser
   * Scans text lines for Dates, Amounts, Balances, and Bank Indicators.
   */
  public parseStatementText(rawText: string, filename = "statement.pdf"): StatementAuditReceipt {
    const lines = rawText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l.length > 0);

    // 1. Detect Bank Pattern
    const lower = rawText.toLowerCase();
    let bankName = "Standard Commercial Bank";
    if (lower.includes("chase") || lower.includes("jpmorgan")) bankName = "JPMorgan Chase Bank";
    else if (lower.includes("bank of america") || lower.includes("bofa")) bankName = "Bank of America";
    else if (lower.includes("wells fargo")) bankName = "Wells Fargo Bank";
    else if (lower.includes("citibank") || lower.includes("citi")) bankName = "Citibank";
    else if (lower.includes("capital one")) bankName = "Capital One";
    else if (lower.includes("stripe")) bankName = "Stripe Treasury / Balance";

    // 2. Extract Account Number (last 4 digits)
    let accountMasked = "**** 0000";
    const acctMatch = rawText.match(/(?:account(?:\s+number)?|acct(?:\s+#)?|ending in)[\s:#]+(\d{4,12})/i);
    if (acctMatch) {
      const fullDigits = acctMatch[1];
      accountMasked = `**** ${fullDigits.slice(-4)}`;
    }

    // 3. Extract Opening & Ending Balances
    let openingCents = 0;
    let endingCents = 0;
    let hasOpening = false;
    let hasEnding = false;

    for (const line of lines) {
      const lineLower = line.toLowerCase();
      // Match Opening / Beginning balance
      if (!hasOpening && (lineLower.includes("beginning balance") || lineLower.includes("starting balance") || lineLower.includes("previous balance") || lineLower.includes("opening balance"))) {
        const amtMatch = line.match(/[-+$]?\s*((?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2})/);
        if (amtMatch) {
          const val = parseFloat(amtMatch[1].replace(/,/g, ""));
          openingCents = StatementVaultCore.toCents(val);
          if (amtMatch[0].trim().startsWith("-")) openingCents = -openingCents;
          hasOpening = true;
        }
      }
      // Match Ending balance
      if (lineLower.includes("ending balance") || lineLower.includes("new balance") || lineLower.includes("closing balance")) {
        const amtMatch = line.match(/[-+$]?\s*((?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2})/);
        if (amtMatch) {
          const val = parseFloat(amtMatch[1].replace(/,/g, ""));
          endingCents = StatementVaultCore.toCents(val);
          if (amtMatch[0].trim().startsWith("-")) endingCents = -endingCents;
          hasEnding = true;
        }
      }
    }

    // 4. Extract Line Item Transactions
    const transactions: StatementTransaction[] = [];
    const dateRegex = /^(\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?|\w{3}\s+\d{1,2}(?:,?\s+\d{4})?)\b/;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const dateMatch = line.match(dateRegex);
      if (!dateMatch) continue;

      const dateStr = dateMatch[1];
      const remainder = line.substring(dateMatch[0].length).trim();

      // Look for dollar amounts at the end or within line: $1,234.56 or 1234.56
      const amounts = Array.from(remainder.matchAll(/([+-]?\$?\s*(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2})/g)).map(m => m[0]);
      if (amounts.length === 0) continue;

      // Extract raw amount
      const rawAmtStr = amounts[0].replace(/[$,\s]/g, "");
      const numAmt = parseFloat(rawAmtStr);
      if (isNaN(numAmt) || Math.abs(numAmt) === 0) continue;

      // Clean description
      let desc = remainder.replace(amounts[0], "").trim();
      if (amounts.length > 1) {
        desc = desc.replace(amounts[1], "").trim();
      }

      // Determine Debit vs Credit
      let type: TransactionType = "DEBIT";
      const descLower = desc.toLowerCase();
      if (rawAmtStr.startsWith("+") || remainder.includes(" CR")) {
        type = "CREDIT";
      } else if (rawAmtStr.startsWith("-")) {
        type = "DEBIT";
      } else {
        const isCredit = descLower.includes("deposit") || descLower.includes("credit") || descLower.includes("refund") || descLower.includes("payroll") || descLower.includes("settlement");
        const isDebit = descLower.includes("withdrawal") || descLower.includes("fee") || descLower.includes("payment") || descLower.includes("purchase") || descLower.includes("debit") || descLower.includes("check #");
        if (isCredit && !isDebit) {
          type = "CREDIT";
        } else {
          type = "DEBIT";
        }
      }

      // Check number detection
      const chkMatch = desc.match(/check\s*#?\s*(\d+)/i);
      const checkNumber = chkMatch ? chkMatch[1] : undefined;

      const absCents = Math.abs(StatementVaultCore.toCents(numAmt));

      transactions.push({
        id: `TX-${transactions.length + 1}`,
        date: dateStr,
        description: desc || "Bank Transaction",
        type: type,
        amountCents: absCents,
        amountFormatted: StatementVaultCore.formatCents(absCents),
        checkNumber
      });
    }

    // 5. Calculate Deterministic Totals
    let totalCreditsCents = 0;
    let totalDebitsCents = 0;

    for (const tx of transactions) {
      if (tx.type === "CREDIT") {
        totalCreditsCents += tx.amountCents;
      } else {
        totalDebitsCents += tx.amountCents;
      }
    }

    // If no explicit ending balance was detected, infer it
    if (!hasEnding && transactions.length > 0) {
      endingCents = openingCents + totalCreditsCents - totalDebitsCents;
    }

    const calculatedEndingBalanceCents = openingCents + totalCreditsCents - totalDebitsCents;
    const discrepancyCents = calculatedEndingBalanceCents - endingCents;
    const isDeterministicPass = (discrepancyCents === 0);

    let auditMessage = "100% Exact Mathematical Balance Match. Opening + Credits - Debits == Ending Balance.";
    if (!isDeterministicPass) {
      const sign = discrepancyCents > 0 ? "+" : "-";
      auditMessage = `Balance Mismatch: Stated ending balance differs by ${sign}${Math.abs(discrepancyCents)}¢. Please verify missing entries or bank fees.`;
    }

    const metadata: StatementMetadata = {
      bankName,
      accountNumberMasked: accountMasked,
      statedOpeningBalanceCents: openingCents,
      statedEndingBalanceCents: endingCents,
      currency: "USD"
    };

    const checksumSha256 = crypto
      .createHash("sha256")
      .update(`${bankName}|${accountMasked}|${openingCents}|${endingCents}|${transactions.length}|${totalCreditsCents}|${totalDebitsCents}`)
      .digest("hex");

    return {
      statementId: `STMT-${checksumSha256.substring(0, 10).toUpperCase()}`,
      metadata,
      transactions,
      totalCreditsCents,
      totalDebitsCents,
      calculatedEndingBalanceCents,
      discrepancyCents,
      isDeterministicPass,
      status: isDeterministicPass ? "EXACT_BALANCE_MATCH" : "DISCREPANCY_FLAGGED",
      auditMessage,
      timestamp: new Date().toISOString(),
      checksumSha256
    };
  }

  /**
   * Export to QuickBooks / Xero 3-Column CSV format (Date, Description, Amount)
   */
  public exportQuickBooksCsv(transactions: StatementTransaction[]): string {
    const header = "Date,Description,Amount\n";
    const rows = transactions.map((tx) => {
      const signedAmt = tx.type === "DEBIT" ? `-${(tx.amountCents / 100).toFixed(2)}` : (tx.amountCents / 100).toFixed(2);
      const cleanDesc = tx.description.replace(/"/g, '""');
      return `"${tx.date}","${cleanDesc}",${signedAmt}`;
    });
    return header + rows.join("\n");
  }

  /**
   * Export to Detailed Audit CSV (Includes Type, Debit, Credit, Running Integrity)
   */
  public exportDetailedAuditCsv(receipt: StatementAuditReceipt): string {
    const metaHeader = `# StatementVault Audit Ledger\n# Bank: ${receipt.metadata.bankName} | Account: ${receipt.metadata.accountNumberMasked}\n# Opening: ${StatementVaultCore.formatCents(receipt.metadata.statedOpeningBalanceCents)} | Ending: ${StatementVaultCore.formatCents(receipt.metadata.statedEndingBalanceCents)}\n# Audit Status: ${receipt.status} (${receipt.auditMessage})\n\n`;
    const colHeader = "TransactionID,Date,Description,Type,DebitUSD,CreditUSD,CheckNumber\n";
    const rows = receipt.transactions.map((tx) => {
      const debitStr = tx.type === "DEBIT" ? (tx.amountCents / 100).toFixed(2) : "0.00";
      const creditStr = tx.type === "CREDIT" ? (tx.amountCents / 100).toFixed(2) : "0.00";
      const cleanDesc = tx.description.replace(/"/g, '""');
      return `"${tx.id}","${tx.date}","${cleanDesc}","${tx.type}",${debitStr},${creditStr},"${tx.checkNumber || ""}"`;
    });
    return metaHeader + colHeader + rows.join("\n");
  }

  /**
   * Export to Standard OFX / QBO Interchange Format (QuickBooks Direct Import)
   */
  public exportToQbo(receipt: StatementAuditReceipt): string {
    const now = new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14);
    const txBlocks = receipt.transactions.map((tx, idx) => {
      const fitid = `${now}${idx}`;
      const trntype = tx.type === "DEBIT" ? "DEBIT" : "CREDIT";
      const trnamt = tx.type === "DEBIT" ? `-${(tx.amountCents / 100).toFixed(2)}` : (tx.amountCents / 100).toFixed(2);
      const dtposted = tx.date.replace(/[^0-9]/g, "").padEnd(8, "0").slice(0, 8);

      return `
<STMTTRN>
<TRNTYPE>${trntype}</TRNTYPE>
<DTPOSTED>${dtposted}</DTPOSTED>
<TRNAMT>${trnamt}</TRNAMT>
<FITID>${fitid}</FITID>
<NAME>${tx.description.substring(0, 32)}</NAME>
</STMTTRN>`;
    }).join("");

    return `OFXHEADER:100
DATA:OFXSGML
VERSION:102
SECURITY:NONE
ENCODING:USASCII
CHARSET:1252
COMPRESSION:NONE
OLDFILEUID:NONE
NEWFILEUID:NONE

<OFX>
<SIGNONMSGSRSV1>
<SONRS>
<STATUS>
<CODE>0</CODE>
<SEVERITY>INFO</SEVERITY>
</STATUS>
<DTSERVER>${now}</DTSERVER>
<LANGUAGE>ENG</LANGUAGE>
</SONRS>
</SIGNONMSGSRSV1>
<BANKMSGSRSV1>
<STMTTRNRS>
<TRNUID>1001</TRNUID>
<STATUS>
<CODE>0</CODE>
<SEVERITY>INFO</SEVERITY>
</STATUS>
<STMTRS>
<CURDEF>USD</CURDEF>
<BANKACCTFROM>
<BANKID>123456789</BANKID>
<ACCTID>${receipt.metadata.accountNumberMasked.replace(/[^0-9]/g, "") || "1001"}</ACCTID>
<ACCTTYPE>CHECKING</ACCTTYPE>
</BANKACCTFROM>
<BANKTRANLIST>
<DTSTART>${now}</DTSTART>
<DTEND>${now}</DTEND>
${txBlocks}
</BANKTRANLIST>
<LEDGERBAL>
<BALAMT>${(receipt.calculatedEndingBalanceCents / 100).toFixed(2)}</BALAMT>
<DTASOF>${now}</DTASOF>
</LEDGERBAL>
</STMTRS>
</STMTTRNRS>
</BANKMSGSRSV1>
</OFX>`;
  }
}
