@echo off
:: StatementVault 1-Click Desktop Launcher
start "" "%~dp0StatementVault-Desktop.html"
exit
