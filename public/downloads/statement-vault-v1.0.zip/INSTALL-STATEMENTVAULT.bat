@echo off
title Installing StatementVault Desktop...
color 0A
echo =======================================================================
echo                   STATEMENT-VAULT 1-CLICK SETUP
echo =======================================================================
echo.
echo [1/2] Creating Desktop Shortcut...

set "TARGET_DIR=%~dp0"
set "APP_FILE=%TARGET_DIR%StatementVault-Desktop.html"

:: Check OneDrive Desktop first, fallback to standard Desktop
set "DESKTOP_DIR=%USERPROFILE%\Desktop"
if exist "%OneDrive%\Desktop" (
    set "DESKTOP_DIR=%OneDrive%\Desktop"
)

set "SHORTCUT_PATH=%DESKTOP_DIR%\StatementVault Desktop.url"

echo [InternetShortcut] > "%SHORTCUT_PATH%"
echo URL=file:///%APP_FILE:\=/% >> "%SHORTCUT_PATH%"
echo IconIndex=0 >> "%SHORTCUT_PATH%"

echo [2/2] Launching StatementVault Desktop in your browser...
start "" "%APP_FILE%"

echo.
echo =======================================================================
echo   Installation Complete! Shortcut placed on your Desktop.
echo =======================================================================
ping -n 2 127.0.0.1 >nul 2>&1
exit /b 0
