const { StatementVaultCore } = require("./dist/statement-vault-core.js");

console.log("=======================================================================");
console.log("     STATEMENT-VAULT 100X STRESS TEST & INTEGRITY VALIDATOR");
console.log("=======================================================================");
console.log("Simulating 100+ high-variance Bank & Credit Card Statement Audits...\n");

const vault = new StatementVaultCore();
let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    passed++;
  } else {
    failed++;
    console.error(`[FAIL] ${message}`);
  }
}

// TEST 1: 50 Valid Bank Statements with Exact Balance Match
console.log("[Phase 1/5] Testing 50 Random Bank Statements with Mathematical Balances...");
for (let i = 1; i <= 50; i++) {
  const opening = 1000.00 + i * 15.25;
  const deposit1 = 500.00 + i * 2.50;
  const deposit2 = 1250.00;
  const debit1 = 200.00 + i;
  const debit2 = 75.50;
  const ending = parseFloat((opening + deposit1 + deposit2 - debit1 - debit2).toFixed(2));

  const text = `
JPMORGAN CHASE BANK
Account Number: 12345678${(1000 + i).toString().slice(-4)}
Beginning Balance: $${opening.toFixed(2)}
Ending Balance: $${ending.toFixed(2)}

TRANSACTIONS:
10/01 PAYROLL DIRECT DEP +$${deposit1.toFixed(2)}
10/05 STRIPE SETTLEMENT +$${deposit2.toFixed(2)}
10/10 OFFICE SUPPLIES CHECK #10${i} -$${debit1.toFixed(2)}
10/15 SOFTWARE SUBSCRIPTION -$${debit2.toFixed(2)}
`;

  const receipt = vault.parseStatementText(text, `test_stmt_${i}.txt`);
  assert(receipt.isDeterministicPass === true, `Stmt ${i} should PASS exact balance check`);
  assert(receipt.discrepancyCents === 0, `Stmt ${i} discrepancy should be 0¢ but got ${receipt.discrepancyCents}¢`);
  assert(receipt.transactions.length === 4, `Stmt ${i} should have 4 transactions`);
}

// TEST 2: 30 Tampered Statements with 1-Cent Discrepancies
console.log("[Phase 2/5] Testing 30 Statements with 1-Cent Discrepancies...");
for (let i = 1; i <= 30; i++) {
  const delta = (i % 2 === 0) ? 0.01 : -0.01;
  const opening = 2000.00;
  const deposit = 1000.00;
  const debit = 500.00;
  const statedEnding = parseFloat((2500.00 + delta).toFixed(2)); // Tampered 1 cent

  const text = `
Bank of America Commercial Checking
Account Number ending in: 9876
Beginning Balance: $${opening.toFixed(2)}
Ending Balance: $${statedEnding.toFixed(2)}

10/02 CLIENT WIRE +$${deposit.toFixed(2)}
10/14 VENDOR INVOICE -$${debit.toFixed(2)}
`;

  const receipt = vault.parseStatementText(text, `tampered_${i}.txt`);
  assert(receipt.isDeterministicPass === false, `Tampered stmt ${i} should FAIL`);
  assert(receipt.status === "DISCREPANCY_FLAGGED", `Tampered stmt ${i} status must be DISCREPANCY_FLAGGED`);
  assert(Math.abs(receipt.discrepancyCents) > 0, `Tampered stmt ${i} must show non-zero discrepancy`);
}

// TEST 3: 20 Credit Card Statements (Wells Fargo & Citi Format)
console.log("[Phase 3/5] Testing 20 Credit Card Formats...");
for (let i = 1; i <= 20; i++) {
  const prevBal = 450.00;
  const payment = 450.00;
  const purchase1 = 120.50 + i;
  const purchase2 = 45.00;
  const newBal = parseFloat((prevBal - payment + purchase1 + purchase2).toFixed(2));

  const text = `
Wells Fargo Business Credit Card
Account ending in 4433
Previous Balance: $${prevBal.toFixed(2)}
New Balance: $${newBal.toFixed(2)}

10/03 AUTOPAY THANK YOU -$${payment.toFixed(2)}
10/11 RESTAURANT CLIENT DINNER +$${purchase1.toFixed(2)}
10/18 AIRLINE BAGGAGE FEE +$${purchase2.toFixed(2)}
`;

  const receipt = vault.parseStatementText(text, `cc_stmt_${i}.txt`);
  assert(receipt.transactions.length === 3, `CC Stmt ${i} should extract 3 lines`);
}

// TEST 4: QuickBooks CSV Export Integrity
console.log("[Phase 4/5] Testing QuickBooks 3-Column CSV Exporter...");
const sampleText = `
Beginning Balance: $1,000.00
Ending Balance: $1,400.00
10/01 DEPOSIT +$500.00
10/05 WITHDRAWAL -$100.00
`;
const sampleReceipt = vault.parseStatementText(sampleText, "sample.txt");
const qbCsv = vault.exportQuickBooksCsv(sampleReceipt.transactions);
assert(qbCsv.includes("Date,Description,Amount"), "QuickBooks CSV must include header");
assert(qbCsv.includes("10/01"), "QuickBooks CSV must include date 10/01");
assert(qbCsv.includes("-100.00"), "QuickBooks CSV must include negative withdrawal -100.00");
assert(qbCsv.includes("500.00"), "QuickBooks CSV must include positive deposit 500.00");

// TEST 5: QBO / OFX SGML Export Integrity
console.log("[Phase 5/5] Testing QBO/OFX Interchange Generator...");
const qboContent = vault.exportToQbo(sampleReceipt);
assert(qboContent.includes("<OFX>"), "QBO must contain <OFX> root tag");
assert(qboContent.includes("<STMTTRN>"), "QBO must contain <STMTTRN> transaction block");
assert(qboContent.includes("<LEDGERBAL>"), "QBO must contain <LEDGERBAL> ledger balance block");

console.log("\n=======================================================================");
console.log(` RESULTS: ${passed} PASSED | ${failed} FAILED`);
console.log("=======================================================================");

if (failed === 0) {
  console.log("✅ ALL 100+ TESTS PASSED WITH 100% DETERMINISTIC PRECISION!");
  process.exit(0);
} else {
  console.error("❌ SOME TESTS FAILED!");
  process.exit(1);
}
