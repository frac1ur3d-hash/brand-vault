@echo off
title ReconVault — Automated Invoice Reconciliation Sweeper
color 0A

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not detected on your PATH.
    echo Please install Node.js from https://nodejs.org to run ReconVault offline.
    echo.
    pause
    exit /b 1
)

cd /d "%~dp0"
node sweep-runner.js

echo.
echo =======================================================================
echo Execution finished. Press any key to exit.
echo =======================================================================
pause >nul
