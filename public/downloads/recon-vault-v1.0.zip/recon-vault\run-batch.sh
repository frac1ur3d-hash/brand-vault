#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"

if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not detected on your PATH."
    echo "Please install Node.js (https://nodejs.org) to run ReconVault offline."
    exit 1
fi

node sweep-runner.js
