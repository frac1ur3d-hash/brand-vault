@echo off
:: ReconVault 1-Click Desktop Launcher
start "" "%~dp0ReconVault-Desktop.html"
exit
