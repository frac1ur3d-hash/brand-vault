@echo off
title Installing ReconVault Desktop...
color 0A
echo =======================================================================
echo                     RECON-VAULT 1-CLICK SETUP
echo =======================================================================
echo.
echo [1/2] Creating Desktop Shortcut...

set "TARGET_DIR=%~dp0"
set "APP_FILE=%TARGET_DIR%ReconVault-Desktop.html"
set "SHORTCUT_PATH=%USERPROFILE%\Desktop\ReconVault Desktop.url"

echo [InternetShortcut] > "%SHORTCUT_PATH%"
echo URL=file:///%APP_FILE:\=/% >> "%SHORTCUT_PATH%"
echo IconIndex=0 >> "%SHORTCUT_PATH%"

echo [2/2] Launching ReconVault Desktop...
start "" "%APP_FILE%"

echo.
echo =======================================================================
echo   Installation Complete! Shortcut placed on your Desktop.
echo =======================================================================
timeout /t 3 >nul
exit
