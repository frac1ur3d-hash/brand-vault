const path = require('path');
const fs = require('fs');
const { ReconVaultCore } = require('./dist/recon-vault-core.js');

console.log('=======================================================================');
console.log('         RECON-VAULT DETERMINISTIC INVOICE RECONCILIATION');
console.log('=======================================================================');
console.log('');
console.log('[1/3] Sweeping "Incoming_Invoices" folder...');
console.log('');

const vault = new ReconVaultCore();
const summary = vault.sweepAndProcessDropFolder();

console.log('-----------------------------------------------------------------------');
console.log(' BATCH PROCESSING COMPLETE');
console.log('-----------------------------------------------------------------------');
console.log(' Total Invoices Reconciled : ' + summary.totalProcessed);
console.log(' Verified (100% Match)     : ' + summary.approvedCount + ' -> Moved to Verified_Ready_For_QuickBooks/');
console.log(' Flagged Discrepancies     : ' + summary.flaggedCount + ' -> Moved to Flagged_Discrepancies/');
console.log('-----------------------------------------------------------------------');

if (summary.flaggedCount > 0) {
  console.log('\n[!] ATTENTION: ' + summary.flaggedCount + ' invoice(s) had penny math errors or tampering.');
  console.log('    Check the "Flagged_Discrepancies" folder for the detailed breakdown reports.');
} else if (summary.totalProcessed > 0) {
  console.log('\n[+] SUCCESS: All invoices passed 100% deterministic integer verification.');
  console.log('    Ready for immediate QuickBooks / Xero import.');
} else {
  console.log('\n[*] No files found in Incoming_Invoices folder.');
  console.log('    Drop your JSON invoices or CSV spreadsheets into Incoming_Invoices and run again.');
}
